package in.umasuraj.j2ee.jsp;

/*
 * JSP is converted to Servlet
 * 
 * file name becomes class names e.g. demo.jsp => demo_jsp.java
 * 
 * 1. DIRECTIVE TAGS
 * 2. DECLARATION TAGS
 * 3. SCRIPLET TAGS
 * 4. EXPRESSION TAGS
 * 
 */

public class JSPMaster {

}
