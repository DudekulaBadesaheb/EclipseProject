package in.umasuraj.j2ee.dao;

public class DataAccessObjectDemo {

	public static void main(String[] args) {
		

	}

}
