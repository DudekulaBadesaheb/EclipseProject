package in.umasuraj.j2ee.jsp;

/*
 * SCIRPLET TAGS
 * -------------
 * 
 * <%  %>
 * 
 * converted to code block / implementation of service method
 * 
 */

public class ScipletTagsMaster {

}
