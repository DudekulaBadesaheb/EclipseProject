package in.umasuraj.j2ee.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class MySqlCreateDatabaseDemo1 {
	private static String jdbcDriver = "com.mysql.cj.jdbc.Driver";
	private static String databaseUrl = "jdbc:mysql://localhost:3306/";
	private static String userPassword = "?user=root&password=root";
	private static String databaseName = "jdbcDemoDB";
	private static Connection connection;
	private static Statement statement;

	public static void main(String[] args) {
		try {

			// Load Driver class
			Class.forName(jdbcDriver);
			connection = DriverManager.getConnection(databaseUrl + userPassword);
			statement = connection.createStatement();
			String sqlQuery = "CREATE DATABASE IF NOT EXISTS " + databaseName;
			statement.executeUpdate(sqlQuery);
			System.out.println("DATABASE_CREATED: " + databaseName);

		} catch (ClassNotFoundException | SQLException ex) {
			ex.printStackTrace();
		}

	}

}
