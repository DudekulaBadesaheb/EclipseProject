package in.umasuraj.j2ee.dao;

public class Student {

	public int rollNo;
	public String name;
}
