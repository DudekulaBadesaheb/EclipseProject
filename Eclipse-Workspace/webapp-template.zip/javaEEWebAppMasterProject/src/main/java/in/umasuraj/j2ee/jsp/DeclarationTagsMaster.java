package in.umasuraj.j2ee.jsp;

/*
 * DECLARATION TAGS
 * -------------
 * 
 * <%!  %>
 * 
 * 
 * ! represents NOT SCRIPLET
 * created inside the class and outside of service method
 * 
 */

public class DeclarationTagsMaster {

}
