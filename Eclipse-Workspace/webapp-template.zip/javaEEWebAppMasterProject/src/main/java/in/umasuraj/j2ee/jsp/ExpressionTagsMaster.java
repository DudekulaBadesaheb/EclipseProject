package in.umasuraj.j2ee.jsp;

/*
 * EXPRESSION TAGS
 * -------------
 * 
 * <%= variableName  %>	=> out.println(variableName);
 * 
 * 
 * 
 */

public class ExpressionTagsMaster {

}
