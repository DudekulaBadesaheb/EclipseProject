package in.umasuraj.j2ee.jsp;

/*
 * DIRECTIVE TAGS
 * -------------
 * 
 * <%@ page attribute="value" %>
 * <%@ page attribute1="value1" attribute2="value2" %>
 * <%@ page import="java.util.Scanner" %>
 * <%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
 * 
 * 
 * JSP Directive
 * @page
 * @include
 * @taglib
 * 
 * 
 */

public class DirectiveTagsMaster {

}
