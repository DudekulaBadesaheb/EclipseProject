package in.umasuraj.j2ee.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class StudentDAO {

	public Student getStudent(int rollNo) {
		Student student;
		Connection connection;
		Statement statement;
		ResultSet resultSet;

		try {
			
			String sqlQuery = "SELECT name FROM student WHERE rollNo=" + rollNo;
			student = new Student();
			student.rollNo = rollNo;
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost/jdbcDemoDB", "root", "root");
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sqlQuery);
			resultSet.next();
			student.name = resultSet.getString("rollNo");

			resultSet.close();
			statement.close();
			connection.close();

			return student;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}
}
