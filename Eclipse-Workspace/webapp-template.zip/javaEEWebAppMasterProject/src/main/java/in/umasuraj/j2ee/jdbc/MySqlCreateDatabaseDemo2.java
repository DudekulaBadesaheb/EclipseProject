package in.umasuraj.j2ee.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class MySqlCreateDatabaseDemo2 {
	private static String jdbcDriver = "com.mysql.cj.jdbc.Driver";
	private static String databaseUrl = "jdbc:mysql://localhost:3306/jdbcDemoDB?createDatabaseIfNotExist=true";
	private static String username = "root";
	private static String password = "root";
	private static Connection connection;
	private static Statement statement;

	public static void main(String[] args) {
		try {

			// Load Driver class
			Class.forName(jdbcDriver);
			connection = DriverManager.getConnection(databaseUrl, username, password);
			statement = connection.createStatement();
			String sqlQuery = "CREATE TABLE student(id INT, name VARCHAR(50))";
			statement.executeUpdate(sqlQuery);
			System.out.println("TABLE_CREATED");

		} catch (ClassNotFoundException | SQLException ex) {
			ex.printStackTrace();
		}

	}

}
